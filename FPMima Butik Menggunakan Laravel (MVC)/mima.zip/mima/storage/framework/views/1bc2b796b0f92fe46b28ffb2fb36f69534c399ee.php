<?php $__env->startSection('content'); ?>

<main class="main">    
  <div class="container-fluid">
    <div class="animated fadeIn">
      <h4>  Manajemen Mix And Match   <br>
       <small>Data Mix And Match   </small>
      </h4>         
      <div class="row">
        <div class="col-md-12">
          <div class="card">          
          <div class="card-body">
      		<?php $__currentLoopData = $swan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                       	
         	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         		<div class="card-body">
              <p style="font-family: cursive;font-size: 25px"><b><?php echo e($datas->nama_mm); ?></b></p>
              <p style="font-family: cursive;font-size: 21px"><sup>Rp</sup> <?php echo e($datas->harga); ?></p>
            </div>
         			
       		<?php $__currentLoopData = $swan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       		<div class="col-sm-6 col-md-4">
         		<div class="card">
         			<div class="card-body" style="align-items: center;"><img src="<?php echo e(URL::asset('../storage/app/public')); ?>/<?php echo e($datas->gambar); ?>" style="max-width:300px;max-height:200px;float:center;border: 0px;border-radius: 5px;" /></div>
         			<div class="card-footer">Nama : <?php echo e($datas->nama); ?></div>
         		</div>
      		</div>
       		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
        </div>
      </div>
    </div>
  </div>
</main>






              
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>