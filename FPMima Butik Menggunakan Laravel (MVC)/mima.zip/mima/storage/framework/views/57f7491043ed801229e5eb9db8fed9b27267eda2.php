<?php $__env->startSection('content'); ?>
<main class="main">    
  <div class="container-fluid">
    <div class="animated fadeIn">
      <h4>  Manajemen Produk<br>
       <small>Data Produk</small>
      </h4>         
        <div class="row">                
          <div class="col-md-12">
            <?php if(!Session::has('editMessage')): ?>
            <div class="card">
              <div class="card-header">
                <i class="fa fa-align-justify"></i> Daftar Produk</div>
                <div class="card-body">
                       	<br>
                    <table class="table table-responsive-sm">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Kategori</th>
                          <th>Nama Produk</th>
                          <th>Harga</th>
                          <th>Warna</th>
                          <th>Stok</th>
                          <th>Gambar</th>  
                          <th>Action</th>                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $dataBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($datas->idBarang); ?></td>
                          <td><?php echo e($datas->nama_kategori); ?></td>
                          <td><?php echo e($datas->nama); ?></td>
                          <td><?php echo e($datas->harga); ?></td>
                          <td><?php echo e($datas->warna); ?></td>
                          <td><?php echo e($datas->stok); ?></td>
                          <td width="10%"><img src="<?php echo e(URL::asset('../storage/app/public')); ?>/<?php echo e($datas->gambar); ?>" style="max-width:300px;max-height:200px;float:center;border: 0px;border-radius: 5px;" /></td>

                          <td width="19%"><a href="<?php echo e(URL('/manageproduct/data/delete')); ?>/<?php echo e($datas->idBarang); ?>"><button class="btn btn-sm" style="background-color: red; color: white;">Delete</button></a> <a href="<?php echo e(URL('/manageproduct/data/update')); ?>/<?php echo e($datas->idBarang); ?>"><button class="btn btn-sm" style="background-color: black; color: white;">Edit</button></a>  </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    <nav>
                    <ul class="pagination">
                      <li class="page-item">
                        <a class="page-link" href="#">Prev</a>
                      </li>
                      <li class="page-item active">
                        <a class="page-link" href="#">1</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">2</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">3</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">4</a>
                      </li>
                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                    </nav>
                </div>
              </div>
              <?php endif; ?>

              
              <?php if(!Session::has('editMessage')): ?>
              <div class="card">
                  <div class="card-header">
                    <strong>Input </strong>Data Produk</div>
                  <div class="card-body">
                    <form role="form" class="form-horizontal" action="<?php echo e(url('/manageproduct/data/prosescreate')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="select1">Kategori</label>
                        <div class="col-md-9">
                          <select class="form-control" name="id_kategori" >
                            <?php $__currentLoopData = $dataKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option id="<?php echo e($datas->id_kategori); ?>" value="<?php echo e($datas->id_kategori); ?>">( <?php echo e($datas->id_kategori); ?> ) <?php echo e($datas->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>                      
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="text-input">Nama</label>
                        <div class="col-md-9">
                          <input class="form-control" type="text" name="nama" placeholder="Text">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="text-input">Harga</label>
                        <div class="col-md-9">
                          <input class="form-control" id="text-input" type="text" name="harga" placeholder="Text">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="select1">Warna</label>
                        <div class="col-md-9">
                          <select class="form-control" id="select1" name="warna">
                            <option value="Biru">Biru</option>
                            <option value="Kuning">Kuning</option>
                            <option value="Hitam">Hitam</option>
                            <option value="Putih">Putih</option>
                            <option value="Merah">Merah</option>
                            <option value="Hijau">Hijau</option>
                            <option value="Coklat">Coklat</option>
                            <option value="Abu-abu">Abu-abu</option>  
                          </select>
                        </div>
                      </div>
                      
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="text-input">Stok</label>
                        <div class="col-md-9">
                          <input class="form-control" id="text-input" type="text" name="stok" placeholder="Text">
                        </div>
                      </div>     
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="file-multiple-input">Upload Photo</label>
                        <div class="col-md-9">
                          <input id="gambar" type="file" name="gambar" multiple="">
                        </div>
                      </div> 
                      <div class="card-footer">
                        <button class="btn btn-sm btn-primary" type="submit">
                          <i class="fa fa-dot-circle-o"></i> Submit</button>
                      </div>                
                    </form>
                  </div>
                </div>
                <?php endif; ?>

                <?php if(Session::has('editMessage')): ?>
                <div class="card">
                  <div class="card-header">
                    <strong>Edit </strong>Data Produk</div>
                  <div class="card-body">
                    <form role="form" class="form-horizontal" action="<?php echo e(url('/manageproduct/data/prosesupdate')); ?>/<?php echo e($dataEdit->idBarang); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="select1" >Kategori</label>
                        <div class="col-md-9">
                          <select class="form-control" name="id_kategori" >
                            <?php $__currentLoopData = $dataKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option id="<?php echo e($datas->id_kategori); ?>" value="<?php echo e($datas->id_kategori); ?>">( <?php echo e($datas->id_kategori); ?> ) <?php echo e($datas->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>                      
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="text-input">Nama</label>
                        <div class="col-md-9">
                          <input class="form-control" type="text" name="nama" placeholder="Text" value="<?php echo e($dataEdit->nama); ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="text-input">Harga</label>
                        <div class="col-md-9">
                          <input class="form-control" id="text-input" type="text" name="harga" placeholder="Text" value="<?php echo e($dataEdit->harga); ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="select1">Warna</label>
                        <div class="col-md-9">
                          <select class="form-control" id="select1" name="warna"  value="<?php echo e($dataEdit->warna); ?>">
                            <option value="Biru">Biru</option>
                            <option value="Kuning">Kuning</option>
                            <option value="Hitam">Hitam</option>
                            <option value="Putih">Putih</option>                            
                            <option value="Merah">Merah</option>
                            <option value="Hijau">Hijau</option>
                            <option value="Coklat">Coklat</option>
                            <option value="Abu-abu">Abu-abu</option>  
                          </select>
                        </div>
                      </div>
                      
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="text-input">Stok</label>
                        <div class="col-md-9">
                          <input class="form-control" id="text-input" type="text" name="stok" placeholder="Text"  value="<?php echo e($dataEdit->stok); ?>">
                        </div>
                      </div>     
                      <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="file-multiple-input">Upload Photo</label>
                        <div class="col-md-9">
                          <input id="gambar" type="file" name="gambar" multiple="">
                        </div>
                      </div> 
                      <div class="card-footer">
                        <button class="btn btn-sm btn-primary" type="submit">
                          <i class="fa fa-dot-circle-o"></i> Submit</button>
                      </div>                
                    </form>
                  </div>
                </div>
                <?php endif; ?>

            </div>
          </div>
        </div>
      </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>